package com.udacity.course3.exercise10.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface MemberRepository {

}
