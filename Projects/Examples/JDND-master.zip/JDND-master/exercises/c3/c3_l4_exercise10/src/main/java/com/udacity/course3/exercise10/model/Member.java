package com.udacity.course3.exercise10.model;

public class Member {
}
