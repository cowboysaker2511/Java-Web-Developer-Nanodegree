package com.udacity.course3.exercise13.repository;

import org.junit.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;

@DataMongoTest
@EnableAutoConfiguration
public class MemberRepositoryTest {

    @Test
    public void contextLoads() {
    }


}