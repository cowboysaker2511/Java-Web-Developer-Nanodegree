package com.udacity.course3.lesson4.exercise4;

public class Application {

    public static void main(String[] args) {
        // STEP 1: Craft the URI to connect to your local MongoDB server
        // Host: localhost
        // Port: 27017 (default)
        // Username: course3
        // Password: course3
        // DB: jdnd-c3
        String uri = "";

        // STEP 2: Create a MongoClient


        // STEP 3: Select the jdnd-c3 database to work with


        // Perform all the steps listed in the exercise






        // IMPORTANT: Make sure to close the MongoClient at the end so your program exits.
    }

}