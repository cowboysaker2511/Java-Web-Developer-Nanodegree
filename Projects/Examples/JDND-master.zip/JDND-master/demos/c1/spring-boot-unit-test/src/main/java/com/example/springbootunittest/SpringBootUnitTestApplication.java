package com.example.springbootunittest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUnitTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUnitTestApplication.class, args);
	}

}
