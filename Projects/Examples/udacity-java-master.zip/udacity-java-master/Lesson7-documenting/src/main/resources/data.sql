INSERT INTO location (id, name, address) VALUES (1, 'ATL Airport','Atlanta airport location');
INSERT INTO location (id, name, address) VALUES (2, 'MIA Airport','Miami airport location');
INSERT INTO location (id, name, address) VALUES (3, 'SFO Airport','San Francisco airport location');
INSERT INTO location (id, name, address) VALUES (4, 'ORD Airport','Chicago airport location');
INSERT INTO location (id, name, address) VALUES (5, 'LGA Airport','New York airport location');

