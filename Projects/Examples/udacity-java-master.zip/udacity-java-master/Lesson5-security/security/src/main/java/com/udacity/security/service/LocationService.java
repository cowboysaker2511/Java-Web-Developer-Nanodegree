package com.udacity.security.service;

import com.udacity.security.entity.Location;

import java.util.List;

public interface LocationService {
    List<Location> getLocations();
}
