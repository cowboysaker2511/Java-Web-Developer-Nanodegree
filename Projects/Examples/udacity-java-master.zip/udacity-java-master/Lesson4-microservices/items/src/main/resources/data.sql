INSERT INTO item (id, name, description) VALUES (1, 'book','A popular book');
INSERT INTO item (id, name, description) VALUES (2, 'candy','A favorite candy');
INSERT INTO item (id, name, description) VALUES (3, 'toy','A simple toy');
INSERT INTO item (id, name, description) VALUES (4, 'food','Your favorite food item');
INSERT INTO item (id, name, description) VALUES (5, 'tv','A flat screen TV');