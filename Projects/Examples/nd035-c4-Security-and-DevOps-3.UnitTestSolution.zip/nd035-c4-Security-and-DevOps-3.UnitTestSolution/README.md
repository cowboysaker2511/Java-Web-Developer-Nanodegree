# Starter Code for JUnit
This branch of contains the startSOLUTION code for the JUnit exercise demonstarted in the classroom. 

1. Nanodegree: Java Web Developer
2. Course: Security and DevOps
3. Lesson: Unit Testing