package com.example.CSV_Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsvDemoApplication.class, args);
	}

}
