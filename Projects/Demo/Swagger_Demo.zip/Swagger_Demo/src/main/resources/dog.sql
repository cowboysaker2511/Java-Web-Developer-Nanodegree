INSERT INTO Dog(id, name, breed, origin)
VALUES (1, 'Name 1', 'Breed 1', 'Origin 3');
INSERT INTO Dog(id, name, breed, origin)
VALUES (2, 'Name 2', 'Breed 2', 'Origin 3');