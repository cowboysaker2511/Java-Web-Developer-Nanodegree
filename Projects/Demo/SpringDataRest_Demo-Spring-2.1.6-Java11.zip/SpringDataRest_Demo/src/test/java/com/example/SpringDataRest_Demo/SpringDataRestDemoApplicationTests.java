package com.example.SpringDataRest_Demo;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import org.junit.Test;

@SpringBootTest
class SpringDataRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
