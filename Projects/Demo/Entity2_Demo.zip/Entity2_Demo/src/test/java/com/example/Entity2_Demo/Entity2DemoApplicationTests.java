package com.example.Entity2_Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Entity2DemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
