package com.example.Entity2_Demo.data;

import jakarta.persistence.Entity;

@Entity
public class Flower extends Plant {
    private String color;

}
