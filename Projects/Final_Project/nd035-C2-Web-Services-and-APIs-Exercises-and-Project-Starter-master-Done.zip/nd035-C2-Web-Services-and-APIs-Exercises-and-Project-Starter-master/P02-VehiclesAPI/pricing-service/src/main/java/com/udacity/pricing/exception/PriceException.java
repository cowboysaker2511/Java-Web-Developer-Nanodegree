package com.udacity.pricing.exception;

public class PriceException extends Exception {

    public PriceException(String message) {
        super(message);
    }
}
