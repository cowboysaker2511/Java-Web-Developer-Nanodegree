package com.udacity.vehicles.entity;

/**
 * Available values for condition of a given car.
 */
public enum Condition {

    USED,
    NEW;
}
